const questions = [
    {
        text: "1. Ce înseamnă HTML?",
        answers: [
            { text: "HyperText Markup Language", correct: true },
            { text: "HighText Machine Language", correct: false }
        ]
    },
    {
        text: "2. Care este cel mai mare titlu în HTML?",
        answers: [
            { text: "&lt;h1&gt;", correct: true },
            { text: "&lt;h6&gt;", correct: false }
        ]
    },
    {
        text: "3. Care este sintaxa corectă pentru a insera o imagine?",
        answers: [
            { text: "&lt;img src=\"imagine.jpg\"&gt;", correct: true },
            { text: "&lt;image&gt;", correct: false }
        ]
    },
    {
        text: "4. Cum se creează un hyperlink?",
        answers: [
            { text: "&lt;a href=\"url\"&gt;text&lt;/a&gt;", correct: true },
            { text: "&lt;link&gt;text&lt;/link&gt;", correct: false }
        ]
    },
    {
        text: "5. Care este tag-ul pentru o linie nouă?",
        answers: [
            { text: "&lt;br&gt;", correct: true },
            { text: "&lt;break&gt;", correct: false }
        ]
    },
    {
        text: "6. Care tag se folosește pentru text îngroșat?",
        answers: [
            { text: "&lt;strong&gt; sau &lt;b&gt;", correct: true },
            { text: "&lt;bold&gt;", correct: false }
        ]
    },
    {
        text: "7. Care sunt elementele principale ale unui document HTML?",
        answers: [
            { text: "&lt;!DOCTYPE&gt;, &lt;html&gt;, &lt;head&gt;, &lt;body&gt;", correct: true },
            { text: "&lt;header&gt;, &lt;main&gt;, &lt;footer&gt;", correct: false }
        ]
    },
    {
        text: "8. Care este tag-ul pentru o listă neordonată?",
        answers: [
            { text: "&lt;ul&gt;", correct: true },
            { text: "&lt;ol&gt;", correct: false }
        ]
    },
    {
        text: "9. Care tag se folosește pentru a defini o celulă de tabel?",
        answers: [
            { text: "&lt;td&gt;", correct: true },
            { text: "&lt;cell&gt;", correct: false }
        ]
    },
    {
        text: "10. Care este tag-ul pentru formulare în HTML?",
        answers: [
            { text: "&lt;form&gt;", correct: true },
            { text: "&lt;input&gt;", correct: false }
        ]
    }
];

let currentQuestion = 0;
let score = 0;
let answered = [false, false, false, false, false, false, false, false, false, false];

// Initializare
function initQuiz() {
    const container = document.getElementById('questionsContainer');
    questions.forEach((question, index) => {
        const questionDiv = document.createElement('div');
        questionDiv.className = `question ${index === 0 ? 'active' : ''}`;
        
        let answersHTML = '<div class="answers">';
        question.answers.forEach((answer, answerIndex) => {
            answersHTML += `<button onclick="selectAnswer(${index}, ${answerIndex}, this)">${answer.text}</button>`;
        });
        answersHTML += '</div>';
        
        questionDiv.innerHTML = `<p>${question.text}</p>${answersHTML}`;
        container.appendChild(questionDiv);
    });
    updateUI();
}

function selectAnswer(questionIndex, answerIndex, button) {
    if (answered[questionIndex]) return;

    answered[questionIndex] = true;
    const isCorrect = questions[questionIndex].answers[answerIndex].correct;
    
    if (isCorrect) {
        score++;
        button.classList.add('correct');
    } else {
        button.classList.add('incorrect');
    }

    // Disable all buttons pentru această întrebare
    const buttons = document.querySelectorAll(`.question:nth-child(${questionIndex + 1}) button`);
    buttons.forEach(btn => btn.disabled = true);

    updateUI();
}

function nextQuestion() {
    if (currentQuestion < questions.length - 1) {
        currentQuestion++;
        updateUI();
    } else {
        showResults();
    }
}

function previousQuestion() {
    if (currentQuestion > 0) {
        currentQuestion--;
        updateUI();
    }
}

function updateUI() {
    // Actualizare întrebări
    document.querySelectorAll('.question').forEach((q, index) => {
        q.classList.toggle('active', index === currentQuestion);
    });

    // Actualizare progres
    const progress = ((currentQuestion + 1) / questions.length) * 100;
    document.getElementById('progressFill').style.width = progress + '%';
    document.getElementById('questionNumber').textContent = `Întrebarea ${currentQuestion + 1}`;

    // Actualizare butoane
    document.getElementById('prevBtn').disabled = currentQuestion === 0;
    document.getElementById('nextBtn').textContent = currentQuestion === questions.length - 1 ? 'Vezi Scorul' : 'Următoare →';
}

function showResults() {
    document.getElementById('questionsContainer').style.display = 'none';
    document.querySelector('.buttons-container').style.display = 'none';
    
    const percentage = Math.round((score / questions.length) * 100);
    document.getElementById('scorText').textContent = `Ai obținut ${score} din ${questions.length} răspunsuri corecte!`;
    document.getElementById('percentageText').textContent = `${percentage}%`;

    let message = '';
    if (percentage === 100) {
        message = "🌟 Felicitări! Ești expert în HTML!";
    } else if (percentage >= 80) {
        message = "🎊 Foarte bine! Ai o cunoaștere solidă!";
    } else if (percentage >= 60) {
        message = "👍 Bine! Ar trebui să mai studiezi puțin!";
    } else if (percentage >= 40) {
        message = "📚 Ai nevoie de mai mult studiu!";
    } else {
        message = "💪 Nu te da bătut! Continua să studiezi!";
    }
    
    document.getElementById('messageText').textContent = message;
    document.getElementById('rezultat').classList.add('show');
}

function resetQuiz() {
    currentQuestion = 0;
    score = 0;
    answered = [false, false, false, false, false, false, false, false, false, false];
    
    document.getElementById('questionsContainer').style.display = 'block';
    document.querySelector('.buttons-container').style.display = 'flex';
    document.getElementById('rezultat').classList.remove('show');

    // Resetare butoane
    document.querySelectorAll('button').forEach(btn => {
        if (!btn.classList.contains('btn-nav') && !btn.classList.contains('btn-reset')) {
            btn.classList.remove('correct', 'incorrect');
            btn.disabled = false;
        }
    });

    updateUI();
}

// Inițializare la încărcarea paginii
window.addEventListener('DOMContentLoaded', initQuiz);